import { Pressable, Text, View } from 'react-native';
import Animated, { FadeInDown } from 'react-native-reanimated';
import { router } from 'expo-router';
import { useQuery } from '@tanstack/react-query';
import type { HomeDashboard } from '@sahhti/domain';
import { ApiClientError, apiRequest } from '../../src/api/client';
import { profileIsComplete } from '../../src/auth/gate';
import { useSession } from '../../src/auth/SessionProvider';
import { formatCount, formatGramsFromMg, formatKg, formatRiyadhDate } from '../../src/format';
import { label } from '../../src/i18n/labels';
import { useLocale } from '../../src/i18n/LocaleProvider';
import { text } from '../../src/i18n/copy';
import { useMotion } from '../../src/theme/motion';
import { fontFamily, radius, spacing, typeScale } from '../../src/theme/tokens';
import { useTheme } from '../../src/theme/ThemeProvider';
import { Button, Screen, ScreenBody } from '../../src/ui/Screen';
import {
  ActivityRing,
  AppHeader,
  EmptyState,
  ErrorState,
  LoadingSkeleton,
  ProfileAvatar,
  SectionLabel,
  Sparkline,
} from '../../src/ui/kit';

type HomeResponse =
  | { onboarded: false; dashboard: null }
  | { onboarded: true; dashboard: HomeDashboard; authoritativeCalorieTarget: null };

type Me = { onboardingCompleted?: boolean; profile: { display_name?: string | null; height_mm?: number | null } | null; goals?: string[] };
type Progress = { weights: { id: string; weight_grams: number; recorded_on: string }[]; completedWorkouts: number };

export default function HomeScreen() {
  const { locale } = useLocale();
  const { tokens } = useSession();
  const theme = useTheme();
  const { reduce } = useMotion();
  const home = useQuery({ queryKey: ['home', locale], queryFn: () => apiRequest<HomeResponse>('/v1/home') });
  const me = useQuery({
    queryKey: ['me', tokens?.accessToken],
    enabled: tokens !== null,
    queryFn: () => apiRequest<Me>('/v1/me'),
  });
  const progress = useQuery({ queryKey: ['progress'], queryFn: () => apiRequest<Progress>('/v1/progress') });

  if (home.isPending) {
    return (
      <Screen>
        <LoadingSkeleton />
      </Screen>
    );
  }
  if (home.error instanceof ApiClientError && home.error.code === 'OFFLINE') {
    return (
      <Screen title={text(locale, 'home')}>
        <ErrorState body={text(locale, 'offline')} onRetry={() => void home.refetch()} />
      </Screen>
    );
  }
  if (home.isError || home.data === undefined) {
    return (
      <Screen title={text(locale, 'home')}>
        <ErrorState body={text(locale, 'error')} onRetry={() => void home.refetch()} />
      </Screen>
    );
  }
  if (!home.data.onboarded || home.data.dashboard === null) {
    if (me.isPending || profileIsComplete(me.data)) {
      return (
        <Screen title={text(locale, 'home')}>
          <LoadingSkeleton />
          <Button label={text(locale, 'tryAgain')} onPress={() => void Promise.all([home.refetch(), me.refetch()])} />
        </Screen>
      );
    }
    return (
      <Screen title={text(locale, 'home')}>
        <EmptyState title={text(locale, 'empty')} body={text(locale, 'welcomeBody')} />
        <Button label={text(locale, 'onboarding')} onPress={() => router.replace('/(onboarding)')} />
      </Screen>
    );
  }

  const dashboard = home.data.dashboard;
  const nutrition = dashboard.nutrition.status === 'ready' ? dashboard.nutrition.data : null;
  const adherence = dashboard.adherence.status === 'ready' ? dashboard.adherence.data : null;
  const ratio = adherence?.ratioBps === null || adherence === null ? null : adherence.ratioBps / 10_000;
  const name = me.data?.profile?.display_name?.trim() || text(locale, 'brand');
  const weights = progress.data?.weights ?? [];
  const latest = weights.length === 0 ? null : weights[weights.length - 1];
  const goal = dashboard.goal.status === 'ready' ? label(locale, 'goal', dashboard.goal.data) : null;
  const logged = nutrition !== null && nutrition.entryCount > 0;
  const today = dashboard.todayWorkout.status === 'ready' ? dashboard.todayWorkout.data : null;
  const actions = [
    [text(locale, 'askCoach'), () => router.push('/(tabs)/coach')],
    [text(locale, 'foodManual'), () => router.push('/(tabs)/nutrition')],
    [text(locale, 'schedule'), () => router.push('/(tabs)/training')],
    [text(locale, 'logWeight'), () => router.push('/weight')],
  ] as const;

  return (
    <Screen>
      <ScreenBody
        footer={
          <Button
            label={today === null ? text(locale, 'createPlan') : text(locale, 'start')}
            onPress={() => {
              if (today === null) {
                router.push('/(tabs)/training');
                return;
              }
              router.push({ pathname: '/workout/[id]', params: { id: today.id } });
            }}
          />
        }
      >
        <Animated.View entering={reduce ? undefined : FadeInDown.duration(280)}>
          <AppHeader
            title={dashboard.greeting}
            subtitle={`${formatRiyadhDate(dashboard.date, locale)}${goal === null ? '' : ` · ${goal}`}`}
            trailing={<ProfileAvatar name={name} onPress={() => router.push('/account')} />}
          />
          <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: spacing[2] }}>
            {actions.map(([labelText, onPress]) => (
              <Pressable
                key={labelText}
                accessibilityRole="button"
                onPress={onPress}
                style={{ backgroundColor: theme.surface, borderRadius: radius.pill, minHeight: 44, justifyContent: 'center', paddingHorizontal: 14, borderWidth: 1, borderColor: theme.border }}
              >
                <Text style={{ color: theme.text, fontFamily: fontFamily.semibold, fontSize: typeScale.label }}>{labelText}</Text>
              </Pressable>
            ))}
          </View>
        </Animated.View>

        <SectionLabel>{text(locale, 'workout')}</SectionLabel>
        {today === null ? (
          <Text style={{ color: theme.text, fontFamily: fontFamily.regular, fontSize: typeScale.body, lineHeight: 24 }}>{text(locale, 'noWorkout')}</Text>
        ) : (
          <Text style={{ color: theme.text, fontFamily: fontFamily.semibold, fontSize: typeScale.body, lineHeight: 24 }}>
            {`${today.name} · ${label(locale, 'discipline', today.discipline)}`}
          </Text>
        )}

        <SectionLabel>{text(locale, 'adherence')}</SectionLabel>
        {adherence !== null && adherence.planned > 0 ? (
          <ActivityRing progress={ratio} label={`${formatCount(adherence.completed, locale)}/${formatCount(adherence.planned, locale)}`} caption={text(locale, 'completedOf')} />
        ) : (
          <Text style={{ color: theme.text, fontFamily: fontFamily.regular, fontSize: typeScale.body, lineHeight: 24 }}>{text(locale, 'weekEmpty')}</Text>
        )}

        {logged && nutrition !== null ? (
          <>
            <SectionLabel>{text(locale, 'nutrition')}</SectionLabel>
            <Text style={{ color: theme.text, fontFamily: fontFamily.semibold, fontSize: typeScale.headline, lineHeight: 32 }}>
              {`${formatCount(nutrition.consumed.energyKcal, locale)} ${text(locale, 'kcal')}`}
              <Text style={{ color: theme.textMuted, fontFamily: fontFamily.regular, fontSize: typeScale.body }}>{`  ·  ${formatGramsFromMg(nutrition.consumed.proteinMg, locale)} ${text(locale, 'grams')} ${text(locale, 'protein')}`}</Text>
            </Text>
          </>
        ) : null}

        {latest !== null ? (
          <>
            <SectionLabel>{text(locale, 'weightTracking')}</SectionLabel>
            <Text style={{ color: theme.text, fontFamily: fontFamily.semibold, fontSize: typeScale.headline, lineHeight: 32 }}>{formatKg(Number(latest.weight_grams), locale)}</Text>
            <Text style={{ color: theme.textMuted, fontFamily: fontFamily.regular, fontSize: typeScale.label, marginBottom: spacing[2] }}>{formatRiyadhDate(String(latest.recorded_on), locale)}</Text>
            <Sparkline values={weights.map((row) => Number(row.weight_grams))} />
          </>
        ) : null}
      </ScreenBody>
    </Screen>
  );
}
