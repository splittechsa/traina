import { router } from 'expo-router';
import { useQuery } from '@tanstack/react-query';
import { ApiClientError, apiRequest } from '../src/api/client';
import { formatCount, formatKg, formatRiyadhDate } from '../src/format';
import { useLocale } from '../src/i18n/LocaleProvider';
import { text } from '../src/i18n/copy';
import { Button, Screen, ScreenBody } from '../src/ui/Screen';
import { AppHeader, EmptyState, ErrorState, ListRow, LoadingSkeleton, Sparkline } from '../src/ui/kit';
import { stableRecordKey } from '../src/lists/keys';

type Progress = {
  weights: { id: string; weight_grams: number; recorded_on: string }[];
  personalRecords: { id: string; exercise_id: string; load_grams: number; reps: number; achieved_at?: string }[];
  completedWorkouts: number;
};

export default function ProgressScreen() {
  const { locale } = useLocale();
  const progress = useQuery({ queryKey: ['progress'], queryFn: () => apiRequest<Progress>('/v1/progress') });
  if (progress.isPending) {
    return (
      <Screen>
        <LoadingSkeleton />
      </Screen>
    );
  }
  if (progress.isError || progress.data === undefined) {
    const offline = progress.error instanceof ApiClientError && progress.error.code === 'OFFLINE';
    return (
      <Screen title={text(locale, 'progress')}>
        <ErrorState body={text(locale, offline ? 'offline' : 'error')} onRetry={() => void progress.refetch()} />
      </Screen>
    );
  }
  if (progress.data.weights.length === 0 && progress.data.personalRecords.length === 0 && progress.data.completedWorkouts === 0) {
    return (
      <Screen>
        <ScreenBody footer={<Button label={text(locale, 'createPlan')} onPress={() => router.push('/(tabs)/training')} />}>
          <AppHeader title={text(locale, 'progress')} />
          <EmptyState title={text(locale, 'progress')} body={text(locale, 'empty')} />
        </ScreenBody>
      </Screen>
    );
  }
  return (
    <Screen>
      <ScreenBody>
        <AppHeader title={text(locale, 'progress')} />
        <ListRow title={text(locale, 'training')} meta={`${formatCount(progress.data.completedWorkouts, locale)} · ${text(locale, 'history')}`} />
        {progress.data.weights.length > 1 ? <Sparkline values={progress.data.weights.map((row) => Number(row.weight_grams))} /> : null}
        {progress.data.weights.map((row) => (
          <ListRow
            key={stableRecordKey(row.id)}
            title={formatKg(Number(row.weight_grams), locale)}
            meta={formatRiyadhDate(String(row.recorded_on), locale)}
          />
        ))}
        {progress.data.personalRecords.map((row) => (
          <ListRow
            key={stableRecordKey(row.id)}
            title={formatKg(Number(row.load_grams), locale)}
            meta={`${formatCount(Number(row.reps), locale)} ${text(locale, 'reps')}`}
          />
        ))}
      </ScreenBody>
    </Screen>
  );
}
