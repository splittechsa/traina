import { useEffect, useState } from 'react';
import { Pressable, Text, View } from 'react-native';
import { useQuery, useQueryClient } from '@tanstack/react-query';
import { useLocalSearchParams } from 'expo-router';
import * as Crypto from 'expo-crypto';
import type { WorkoutSession } from '@sahhti/domain';
import { parseScaledInteger } from '@sahhti/domain';
import { ApiClientError, apiRequest } from '../../src/api/client';
import { formatCount, formatKg } from '../../src/format';
import { label } from '../../src/i18n/labels';
import { useLocale } from '../../src/i18n/LocaleProvider';
import { text } from '../../src/i18n/copy';
import { Body, Button, Field, Screen, ScreenBody } from '../../src/ui/Screen';
import { AppHeader, ErrorState, ListRow, LoadingSkeleton } from '../../src/ui/kit';
import { fontFamily, radius, typeScale } from '../../src/theme/tokens';
import { useTheme } from '../../src/theme/ThemeProvider';
import { useMotion } from '../../src/theme/motion';
import { tapSuccess } from '../../src/ui/haptics';
import { planOfflineSync, type PendingSetCommand } from '../../src/offline/queue';
import { readPendingSets, writePendingSets } from '../../src/offline/sqlite';

export default function WorkoutScreen() {
  const { id } = useLocalSearchParams<{ id: string }>();
  const { locale } = useLocale();
  const { reduce } = useMotion();
  const client = useQueryClient();
  const theme = useTheme();
  const [reps, setReps] = useState('8');
  const [load, setLoad] = useState('');
  const [notice, setNotice] = useState('');
  const [rest, setRest] = useState(0);
  const [activeExerciseId, setActiveExerciseId] = useState('');
  const session = useQuery({
    queryKey: ['session', id],
    enabled: typeof id === 'string',
    queryFn: () => apiRequest<{ session: WorkoutSession }>(`/v1/training/sessions/${id}`),
  });

  useEffect(() => {
    if (rest <= 0) {
      return;
    }
    const timer = setInterval(() => setRest((current) => (current <= 1 ? 0 : current - 1)), 1000);
    return () => clearInterval(timer);
  }, [rest]);

  async function start() {
    if (typeof id !== 'string') return;
    await apiRequest(`/v1/training/sessions/${id}/start`, { method: 'POST', body: { at: new Date().toISOString() } });
    await client.invalidateQueries({ queryKey: ['session', id] });
  }

  async function pause() {
    if (typeof id !== 'string') return;
    await apiRequest(`/v1/training/sessions/${id}/pause`, { method: 'POST', body: { at: new Date().toISOString() } });
    await client.invalidateQueries({ queryKey: ['session', id] });
  }

  async function resume() {
    if (typeof id !== 'string') return;
    await apiRequest(`/v1/training/sessions/${id}/resume`, { method: 'POST', body: { at: new Date().toISOString() } });
    await client.invalidateQueries({ queryKey: ['session', id] });
  }

  async function complete() {
    if (typeof id !== 'string') return;
    await apiRequest(`/v1/training/sessions/${id}/complete`, { method: 'POST', body: { at: new Date().toISOString() } });
    await client.invalidateQueries({ queryKey: ['session', id] });
    await client.invalidateQueries({ queryKey: ['sessions'] });
    await client.invalidateQueries({ queryKey: ['home'] });
    await client.invalidateQueries({ queryKey: ['progress'] });
  }

  async function logSet() {
    if (typeof id !== 'string' || session.data === undefined) return;
    const planned =
      session.data.session.plannedExercises.find((item) => item.exerciseId === activeExerciseId) ??
      session.data.session.plannedExercises[0];
    if (planned === undefined) {
      setNotice(text(locale, 'empty'));
      return;
    }
    const bodyweight = planned.prescription.kind !== 'strength';
    const command: PendingSetCommand = {
      clientEventId: Crypto.randomUUID(),
      sessionId: id,
      set: {
        id: Crypto.randomUUID(),
        exerciseId: planned.exerciseId,
        setIndex: session.data.session.sets.length + 1,
        reps: Number(reps),
        loadGrams: bodyweight || load.trim().length === 0 ? 0 : parseScaledInteger(load, 1000),
        rpeTenths: null,
        completedAt: new Date().toISOString(),
      },
    };
    try {
      await apiRequest(`/v1/training/sessions/${id}/sets`, { method: 'POST', body: command.set });
      await client.invalidateQueries({ queryKey: ['session', id] });
      setNotice('');
      tapSuccess(reduce);
      if (planned.prescription.kind === 'strength') {
        setRest(planned.prescription.restSeconds);
      }
    } catch (caught) {
      if (!(caught instanceof ApiClientError) || caught.code !== 'OFFLINE') {
        setNotice(text(locale, 'error'));
        return;
      }
      const pending = await readPendingSets();
      const others = pending.filter((item) => item.sessionId !== id);
      const plan = planOfflineSync(session.data.session, [...pending.filter((item) => item.sessionId === id), command]);
      if (plan.conflicts.some((conflict) => conflict.clientEventId === command.clientEventId)) {
        setNotice(text(locale, 'conflict'));
        return;
      }
      await writePendingSets([...others, ...plan.send]);
      setNotice(text(locale, 'queued'));
    }
  }

  async function sync() {
    if (typeof id !== 'string' || session.data === undefined) return;
    const pending = await readPendingSets();
    const mine = pending.filter((command) => command.sessionId === id);
    const others = pending.filter((command) => command.sessionId !== id);
    const plan = planOfflineSync(session.data.session, mine);
    const remaining = [...others];
    if (plan.conflicts.length > 0) {
      setNotice(text(locale, 'conflict'));
    }
    for (const command of plan.send) {
      try {
        await apiRequest(`/v1/training/sessions/${command.sessionId}/sets`, { method: 'POST', body: command.set });
      } catch (caught) {
        if (caught instanceof ApiClientError && caught.status === 409) {
          setNotice(text(locale, 'conflict'));
          continue;
        }
        remaining.push(command);
      }
    }
    await writePendingSets(remaining);
    await client.invalidateQueries({ queryKey: ['session', id] });
  }

  if (session.isPending) {
    return (
      <Screen>
        <LoadingSkeleton />
      </Screen>
    );
  }
  if (session.isError || session.data === undefined) {
    const offline = session.error instanceof ApiClientError && session.error.code === 'OFFLINE';
    return (
      <Screen title={text(locale, 'workout')}>
        <ErrorState body={text(locale, offline ? 'offline' : 'error')} />
      </Screen>
    );
  }
  const current = session.data.session;
  const active =
    current.plannedExercises.find((item) => item.exerciseId === activeExerciseId) ?? current.plannedExercises[0];
  const primary =
    current.status === 'scheduled'
      ? { label: text(locale, 'start'), onPress: () => void start() }
      : current.status === 'paused'
        ? { label: text(locale, 'resume'), onPress: () => void resume() }
        : current.status === 'in_progress'
          ? { label: text(locale, 'logSet'), onPress: () => void logSet() }
          : null;
  return (
    <Screen>
      <ScreenBody
        footer={
          primary === null ? undefined : (
            <>
              {primary !== null ? <Button label={primary.label} onPress={primary.onPress} /> : null}
              {current.status === 'in_progress' || current.status === 'paused' ? (
                <Button label={text(locale, 'finish')} variant="lime" onPress={() => void complete()} />
              ) : null}
            </>
          )
        }
      >
        <AppHeader title={current.name} subtitle={label(locale, 'session', current.status)} />
        {rest > 0 ? <Body>{`${text(locale, 'rest')} ${formatCount(rest, locale)} ${text(locale, 'seconds')}`}</Body> : null}
        {current.sets.map((set) => (
          <ListRow
            key={set.id}
            title={set.loadGrams === 0 ? formatCount(set.reps, locale) : `${formatCount(set.reps, locale)} × ${formatKg(set.loadGrams, locale)}`}
            meta={`${text(locale, 'sets')} ${formatCount(set.setIndex, locale)}`}
          />
        ))}
        {current.plannedExercises.map((planned) => {
          const active = (activeExerciseId.length === 0 ? current.plannedExercises[0]?.exerciseId : activeExerciseId) === planned.exerciseId;
          return (
            <ListRow
              key={planned.exerciseId}
              title={planned.prescription.kind === 'crossfit' ? planned.prescription.format : planned.prescription.kind === 'calisthenics' ? planned.prescription.progression : `${formatCount(planned.prescription.sets, locale)} × ${formatCount(planned.prescription.reps, locale)}`}
              meta={label(locale, 'discipline', current.discipline)}
              trailing={active ? '✓' : undefined}
              onPress={() => setActiveExerciseId(planned.exerciseId)}
            />
          );
        })}
        {current.status === 'in_progress' ? (
          <>
            <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 8 }}>
              {['5', '8', '10', '12'].map((value) => (
                <Pressable
                  key={value}
                  accessibilityRole="button"
                  onPress={() => setReps(value)}
                  style={{ minHeight: 44, minWidth: 44, alignItems: 'center', justifyContent: 'center', borderRadius: radius.pill, borderWidth: 1, borderColor: theme.border, paddingHorizontal: 12 }}
                >
                  <Text style={{ color: theme.text, fontFamily: fontFamily.semibold, fontSize: typeScale.label }}>{formatCount(Number(value), locale)}</Text>
                </Pressable>
              ))}
            </View>
            <Field
              label={active === undefined ? text(locale, 'reps') : active.prescription.kind === 'crossfit' ? text(locale, 'rounds') : active.prescription.kind === 'calisthenics' && active.prescription.holdSeconds !== null ? text(locale, 'hold') : text(locale, 'reps')}
              value={reps}
              onChangeText={setReps}
              keyboardType="number-pad"
            />
            {active === undefined || active.prescription.kind === 'strength' ? (
              <Field label={`${text(locale, 'load')} (${text(locale, 'kilograms')})`} value={load} onChangeText={setLoad} keyboardType="decimal-pad" />
            ) : null}
          </>
        ) : null}
        {notice.length > 0 ? <Body>{notice}</Body> : null}
        {current.status === 'in_progress' ? <Button label={text(locale, 'pause')} variant="secondary" onPress={() => void pause()} /> : null}
        <Button label={text(locale, 'sync')} variant="secondary" onPress={() => void sync()} />
      </ScreenBody>
    </Screen>
  );
}
