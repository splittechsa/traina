export const brand = {
  charcoal: '#161411',
  green: '#3E6B56',
  lime: '#E0A24A',
  paper: '#F3EEE6',
  violet: '#C9B7A2',
} as const;

export type Palette = {
  scheme: 'light' | 'dark';
  background: string;
  surface: string;
  surfaceMuted: string;
  text: string;
  textMuted: string;
  border: string;
  accent: string;
  emphasis: string;
  emphasisText: string;
  lime: string;
  limeInk: string;
  violet: string;
  hero: string;
  heroText: string;
  heroAccent: string;
  danger: string;
  warning: string;
  success: string;
  focus: string;
  ringTrack: string;
};

export const light: Palette = {
  scheme: 'light',
  background: '#F3EEE6',
  surface: '#FFFBF6',
  surfaceMuted: '#E7E0D6',
  text: '#1C1915',
  textMuted: '#6E655C',
  border: '#DDD4C8',
  accent: brand.lime,
  emphasis: '#1C1915',
  emphasisText: '#F3EEE6',
  lime: brand.lime,
  limeInk: '#1C1915',
  violet: brand.violet,
  hero: '#1C1915',
  heroText: '#F3EEE6',
  heroAccent: brand.lime,
  danger: '#9B3A3A',
  warning: '#8A5A12',
  success: '#3E6B56',
  focus: brand.lime,
  ringTrack: '#E7E0D6',
};

export const dark: Palette = {
  scheme: 'dark',
  background: '#100E0C',
  surface: '#1A1714',
  surfaceMuted: '#26211C',
  text: '#F6F1E8',
  textMuted: '#B7AEA3',
  border: '#3A332C',
  accent: brand.lime,
  emphasis: brand.lime,
  emphasisText: '#1C1915',
  lime: brand.lime,
  limeInk: '#1C1915',
  violet: brand.violet,
  hero: '#0C0B0A',
  heroText: '#F6F1E8',
  heroAccent: brand.lime,
  danger: '#E08A8A',
  warning: '#E2C27A',
  success: '#8FB59A',
  focus: brand.lime,
  ringTrack: '#2A261F',
};

export const spacing = [0, 4, 8, 12, 16, 24, 32, 48] as const;
export const radius = { sm: 12, md: 16, lg: 24, pill: 999 } as const;

export const typeScale = {
  display: 44,
  title: 28,
  headline: 22,
  card: 18,
  body: 16,
  label: 13,
  numeric: 40,
} as const;

export const fontFamily = {
  regular: 'IBMPlexSansArabic_400Regular',
  medium: 'IBMPlexSansArabic_500Medium',
  semibold: 'IBMPlexSansArabic_600SemiBold',
  bold: 'IBMPlexSansArabic_700Bold',
} as const;

/** IBM Plex Sans Arabic is used for Arabic and Latin. Licensed under the SIL Open Font License. */
export const fontIntent = {
  arabic: 'IBM Plex Sans Arabic',
  latin: 'IBM Plex Sans Arabic',
} as const;
